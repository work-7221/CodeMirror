public class TwoSumStudent_39 {
    public static int[] solve(int[] data, int target) {
        
        java.util.Map<Integer,Integer> lookup = new java.util.HashMap<>();
        int i=0;
        while(i < data.length){
            int diff = target - data[i];
            if(lookup.containsKey(diff)){
                return new int[]{lookup.get(diff), i};
            }
            lookup.put(data[i], i);
            i++;
        }
        return new int[]{-1,-1};
        
    }
}