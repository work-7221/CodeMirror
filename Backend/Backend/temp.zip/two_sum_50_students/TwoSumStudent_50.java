public class TwoSumStudent_50 {
    public static int[] solve(int[] nums, int target) {
        
        for(int index=0; index<nums.length; index++){
            int need = target - nums[index];
            for(int j=0; j<nums.length; j++){
                if(index!=j && nums[j] == need){
                    return new int[]{index,j};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}