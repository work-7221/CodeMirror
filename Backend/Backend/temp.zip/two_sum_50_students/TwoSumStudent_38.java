public class TwoSumStudent_38 {
    public static int[] solve(int[] numbers, int target) {
        
        int n = numbers.length;
        for(int x=0; x<n-1; x++){
            for(int pos=x+1; pos<n; pos++){
                int sum = numbers[x] + numbers[pos];
                if(sum == target){
                    return new int[]{x,pos};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}