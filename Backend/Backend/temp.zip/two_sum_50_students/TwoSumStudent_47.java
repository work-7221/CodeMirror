public class TwoSumStudent_47 {
    public static int[] solve(int[] numbers, int target) {
        
        java.util.HashMap<Integer,Integer> store = new java.util.HashMap<>();
        for(int x=0; x<numbers.length; x++){
            int complement = target - numbers[x];
            if(store.containsKey(complement)){
                return new int[]{store.get(complement), x};
            }
            store.put(numbers[x], x);
        }
        return new int[]{-1,-1};
        
    }
}