public class TwoSumStudent_5 {
    public static int[] solve(int[] numbers, int target) {
        
        for(int k=0; k<numbers.length; k++){
            int need = target - numbers[k];
            for(int pos=0; pos<numbers.length; pos++){
                if(k!=pos && numbers[pos] == need){
                    return new int[]{k,pos};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}