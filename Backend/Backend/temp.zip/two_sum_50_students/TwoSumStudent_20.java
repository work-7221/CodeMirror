public class TwoSumStudent_20 {
    public static int[] solve(int[] data, int target) {
        
        for(int k=0; k<data.length; k++){
            int need = target - data[k];
            for(int m=0; m<data.length; m++){
                if(k!=m && data[m] == need){
                    return new int[]{k,m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}