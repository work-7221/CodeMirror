public class TwoSumStudent_27 {
    public static int[] solve(int[] nums, int target) {
        
        java.util.HashMap<Integer,Integer> store = new java.util.HashMap<>();
        for(int idx=0; idx<nums.length; idx++){
            int complement = target - nums[idx];
            if(store.containsKey(complement)){
                return new int[]{store.get(complement), idx};
            }
            store.put(nums[idx], idx);
        }
        return new int[]{-1,-1};
        
    }
}