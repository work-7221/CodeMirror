public class TwoSumStudent_24 {
    public static int[] solve(int[] data, int target) {
        
        java.util.Map<Integer,Integer> lookup = new java.util.HashMap<>();
        int index=0;
        while(index < data.length){
            int diff = target - data[index];
            if(lookup.containsKey(diff)){
                return new int[]{lookup.get(diff), index};
            }
            lookup.put(data[index], index);
            index++;
        }
        return new int[]{-1,-1};
        
    }
}