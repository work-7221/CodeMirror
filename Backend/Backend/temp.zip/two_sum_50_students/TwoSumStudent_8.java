public class TwoSumStudent_8 {
    public static int[] solve(int[] arr, int target) {
        
        int n = arr.length;
        for(int index=0; index<n-1; index++){
            for(int m=index+1; m<n; m++){
                int sum = arr[index] + arr[m];
                if(sum == target){
                    return new int[]{index,m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}