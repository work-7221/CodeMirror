public class TwoSumStudent_1 {
    public static int[] solve(int[] arr, int target) {
        
        for(int i=0; i<arr.length; i++){
            for(int m=i+1; m<arr.length; m++){
                if(arr[i] + arr[m] == target){
                    return new int[]{i, m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}