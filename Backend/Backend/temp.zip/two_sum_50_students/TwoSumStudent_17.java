public class TwoSumStudent_17 {
    public static int[] solve(int[] arr, int target) {
        
        java.util.HashMap<Integer,Integer> hash = new java.util.HashMap<>();
        for(int idx=0; idx<arr.length; idx++){
            int complement = target - arr[idx];
            if(hash.containsKey(complement)){
                return new int[]{hash.get(complement), idx};
            }
            hash.put(arr[idx], idx);
        }
        return new int[]{-1,-1};
        
    }
}