public class TwoSumStudent_4 {
    public static int[] solve(int[] nums, int target) {
        
        java.util.Map<Integer,Integer> hash = new java.util.HashMap<>();
        int index=0;
        while(index < nums.length){
            int diff = target - nums[index];
            if(hash.containsKey(diff)){
                return new int[]{hash.get(diff), index};
            }
            hash.put(nums[index], index);
            index++;
        }
        return new int[]{-1,-1};
        
    }
}