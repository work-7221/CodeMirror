public class TwoSumStudent_22 {
    public static int[] solve(int[] input, int target) {
        
        java.util.HashMap<Integer,Integer> lookup = new java.util.HashMap<>();
        for(int k=0; k<input.length; k++){
            int complement = target - input[k];
            if(lookup.containsKey(complement)){
                return new int[]{lookup.get(complement), k};
            }
            lookup.put(input[k], k);
        }
        return new int[]{-1,-1};
        
    }
}