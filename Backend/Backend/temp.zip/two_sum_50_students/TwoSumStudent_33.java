public class TwoSumStudent_33 {
    public static int[] solve(int[] input, int target) {
        
        int n = input.length;
        for(int i=0; i<n-1; i++){
            for(int y=i+1; y<n; y++){
                int sum = input[i] + input[y];
                if(sum == target){
                    return new int[]{i,y};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}