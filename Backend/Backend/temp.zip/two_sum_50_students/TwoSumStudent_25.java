public class TwoSumStudent_25 {
    public static int[] solve(int[] arr, int target) {
        
        for(int i=0; i<arr.length; i++){
            int need = target - arr[i];
            for(int y=0; y<arr.length; y++){
                if(i!=y && arr[y] == need){
                    return new int[]{i,y};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}