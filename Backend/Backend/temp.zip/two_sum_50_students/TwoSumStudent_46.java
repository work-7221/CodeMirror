public class TwoSumStudent_46 {
    public static int[] solve(int[] input, int target) {
        
        for(int index=0; index<input.length; index++){
            for(int z=index+1; z<input.length; z++){
                if(input[index] + input[z] == target){
                    return new int[]{index, z};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}