public class TwoSumStudent_14 {
    public static int[] solve(int[] nums, int target) {
        
        java.util.Map<Integer,Integer> map = new java.util.HashMap<>();
        int k=0;
        while(k < nums.length){
            int diff = target - nums[k];
            if(map.containsKey(diff)){
                return new int[]{map.get(diff), k};
            }
            map.put(nums[k], k);
            k++;
        }
        return new int[]{-1,-1};
        
    }
}