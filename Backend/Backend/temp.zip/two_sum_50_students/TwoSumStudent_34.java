public class TwoSumStudent_34 {
    public static int[] solve(int[] input, int target) {
        
        java.util.Map<Integer,Integer> lookup = new java.util.HashMap<>();
        int k=0;
        while(k < input.length){
            int diff = target - input[k];
            if(lookup.containsKey(diff)){
                return new int[]{lookup.get(diff), k};
            }
            lookup.put(input[k], k);
            k++;
        }
        return new int[]{-1,-1};
        
    }
}