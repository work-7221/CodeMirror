public class TwoSumStudent_6 {
    public static int[] solve(int[] arr, int target) {
        
        for(int idx=0; idx<arr.length; idx++){
            for(int m=idx+1; m<arr.length; m++){
                if(arr[idx] + arr[m] == target){
                    return new int[]{idx, m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}