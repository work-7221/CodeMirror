public class TwoSumStudent_45 {
    public static int[] solve(int[] nums, int target) {
        
        for(int x=0; x<nums.length; x++){
            int need = target - nums[x];
            for(int j=0; j<nums.length; j++){
                if(x!=j && nums[j] == need){
                    return new int[]{x,j};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}