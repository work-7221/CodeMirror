public class TwoSumStudent_16 {
    public static int[] solve(int[] arr, int target) {
        
        for(int k=0; k<arr.length; k++){
            for(int pos=k+1; pos<arr.length; pos++){
                if(arr[k] + arr[pos] == target){
                    return new int[]{k, pos};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}