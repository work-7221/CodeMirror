public class TwoSumStudent_23 {
    public static int[] solve(int[] arr, int target) {
        
        int n = arr.length;
        for(int idx=0; idx<n-1; idx++){
            for(int m=idx+1; m<n; m++){
                int sum = arr[idx] + arr[m];
                if(sum == target){
                    return new int[]{idx,m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}