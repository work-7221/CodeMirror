public class TwoSumStudent_36 {
    public static int[] solve(int[] numbers, int target) {
        
        for(int i=0; i<numbers.length; i++){
            for(int m=i+1; m<numbers.length; m++){
                if(numbers[i] + numbers[m] == target){
                    return new int[]{i, m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}