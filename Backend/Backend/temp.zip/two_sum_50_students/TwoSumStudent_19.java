public class TwoSumStudent_19 {
    public static int[] solve(int[] arr, int target) {
        
        java.util.Map<Integer,Integer> store = new java.util.HashMap<>();
        int index=0;
        while(index < arr.length){
            int diff = target - arr[index];
            if(store.containsKey(diff)){
                return new int[]{store.get(diff), index};
            }
            store.put(arr[index], index);
            index++;
        }
        return new int[]{-1,-1};
        
    }
}