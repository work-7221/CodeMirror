public class TwoSumStudent_15 {
    public static int[] solve(int[] numbers, int target) {
        
        for(int i=0; i<numbers.length; i++){
            int need = target - numbers[i];
            for(int z=0; z<numbers.length; z++){
                if(i!=z && numbers[z] == need){
                    return new int[]{i,z};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}