public class TwoSumStudent_2 {
    public static int[] solve(int[] data, int target) {
        
        java.util.HashMap<Integer,Integer> store = new java.util.HashMap<>();
        for(int i=0; i<data.length; i++){
            int complement = target - data[i];
            if(store.containsKey(complement)){
                return new int[]{store.get(complement), i};
            }
            store.put(data[i], i);
        }
        return new int[]{-1,-1};
        
    }
}