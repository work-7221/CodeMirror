public class TwoSumStudent_3 {
    public static int[] solve(int[] data, int target) {
        
        int n = data.length;
        for(int i=0; i<n-1; i++){
            for(int j=i+1; j<n; j++){
                int sum = data[i] + data[j];
                if(sum == target){
                    return new int[]{i,j};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}