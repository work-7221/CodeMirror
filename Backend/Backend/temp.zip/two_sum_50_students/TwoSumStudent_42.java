public class TwoSumStudent_42 {
    public static int[] solve(int[] data, int target) {
        
        java.util.HashMap<Integer,Integer> store = new java.util.HashMap<>();
        for(int k=0; k<data.length; k++){
            int complement = target - data[k];
            if(store.containsKey(complement)){
                return new int[]{store.get(complement), k};
            }
            store.put(data[k], k);
        }
        return new int[]{-1,-1};
        
    }
}