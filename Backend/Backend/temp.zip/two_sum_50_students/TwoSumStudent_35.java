public class TwoSumStudent_35 {
    public static int[] solve(int[] nums, int target) {
        
        for(int x=0; x<nums.length; x++){
            int need = target - nums[x];
            for(int pos=0; pos<nums.length; pos++){
                if(x!=pos && nums[pos] == need){
                    return new int[]{x,pos};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}