public class TwoSumStudent_40 {
    public static int[] solve(int[] arr, int target) {
        
        for(int x=0; x<arr.length; x++){
            int need = target - arr[x];
            for(int m=0; m<arr.length; m++){
                if(x!=m && arr[m] == need){
                    return new int[]{x,m};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}