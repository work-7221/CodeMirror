public class TwoSumStudent_49 {
    public static int[] solve(int[] numbers, int target) {
        
        java.util.Map<Integer,Integer> hm = new java.util.HashMap<>();
        int index=0;
        while(index < numbers.length){
            int diff = target - numbers[index];
            if(hm.containsKey(diff)){
                return new int[]{hm.get(diff), index};
            }
            hm.put(numbers[index], index);
            index++;
        }
        return new int[]{-1,-1};
        
    }
}