public class TwoSumStudent_32 {
    public static int[] solve(int[] data, int target) {
        
        java.util.HashMap<Integer,Integer> hm = new java.util.HashMap<>();
        for(int k=0; k<data.length; k++){
            int complement = target - data[k];
            if(hm.containsKey(complement)){
                return new int[]{hm.get(complement), k};
            }
            hm.put(data[k], k);
        }
        return new int[]{-1,-1};
        
    }
}