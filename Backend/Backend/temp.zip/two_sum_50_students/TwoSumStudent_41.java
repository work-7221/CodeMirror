public class TwoSumStudent_41 {
    public static int[] solve(int[] data, int target) {
        
        for(int k=0; k<data.length; k++){
            for(int y=k+1; y<data.length; y++){
                if(data[k] + data[y] == target){
                    return new int[]{k, y};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}