public class TwoSumStudent_12 {
    public static int[] solve(int[] numbers, int target) {
        
        java.util.HashMap<Integer,Integer> lookup = new java.util.HashMap<>();
        for(int i=0; i<numbers.length; i++){
            int complement = target - numbers[i];
            if(lookup.containsKey(complement)){
                return new int[]{lookup.get(complement), i};
            }
            lookup.put(numbers[i], i);
        }
        return new int[]{-1,-1};
        
    }
}