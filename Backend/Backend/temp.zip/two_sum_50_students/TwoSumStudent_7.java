public class TwoSumStudent_7 {
    public static int[] solve(int[] arr, int target) {
        
        java.util.HashMap<Integer,Integer> map = new java.util.HashMap<>();
        for(int x=0; x<arr.length; x++){
            int complement = target - arr[x];
            if(map.containsKey(complement)){
                return new int[]{map.get(complement), x};
            }
            map.put(arr[x], x);
        }
        return new int[]{-1,-1};
        
    }
}