public class TwoSumStudent_48 {
    public static int[] solve(int[] input, int target) {
        
        int n = input.length;
        for(int idx=0; idx<n-1; idx++){
            for(int j=idx+1; j<n; j++){
                int sum = input[idx] + input[j];
                if(sum == target){
                    return new int[]{idx,j};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}