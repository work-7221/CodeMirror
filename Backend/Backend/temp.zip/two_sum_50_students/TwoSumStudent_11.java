public class TwoSumStudent_11 {
    public static int[] solve(int[] arr, int target) {
        
        for(int i=0; i<arr.length; i++){
            for(int y=i+1; y<arr.length; y++){
                if(arr[i] + arr[y] == target){
                    return new int[]{i, y};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}