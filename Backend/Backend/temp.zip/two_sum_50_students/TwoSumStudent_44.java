public class TwoSumStudent_44 {
    public static int[] solve(int[] input, int target) {
        
        java.util.Map<Integer,Integer> hm = new java.util.HashMap<>();
        int idx=0;
        while(idx < input.length){
            int diff = target - input[idx];
            if(hm.containsKey(diff)){
                return new int[]{hm.get(diff), idx};
            }
            hm.put(input[idx], idx);
            idx++;
        }
        return new int[]{-1,-1};
        
    }
}