public class TwoSumStudent_29 {
    public static int[] solve(int[] input, int target) {
        
        java.util.Map<Integer,Integer> lookup = new java.util.HashMap<>();
        int i=0;
        while(i < input.length){
            int diff = target - input[i];
            if(lookup.containsKey(diff)){
                return new int[]{lookup.get(diff), i};
            }
            lookup.put(input[i], i);
            i++;
        }
        return new int[]{-1,-1};
        
    }
}