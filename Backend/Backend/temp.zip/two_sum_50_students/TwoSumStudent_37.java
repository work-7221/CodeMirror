public class TwoSumStudent_37 {
    public static int[] solve(int[] arr, int target) {
        
        java.util.HashMap<Integer,Integer> map = new java.util.HashMap<>();
        for(int i=0; i<arr.length; i++){
            int complement = target - arr[i];
            if(map.containsKey(complement)){
                return new int[]{map.get(complement), i};
            }
            map.put(arr[i], i);
        }
        return new int[]{-1,-1};
        
    }
}