public class TwoSumStudent_13 {
    public static int[] solve(int[] input, int target) {
        
        int n = input.length;
        for(int idx=0; idx<n-1; idx++){
            for(int y=idx+1; y<n; y++){
                int sum = input[idx] + input[y];
                if(sum == target){
                    return new int[]{idx,y};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}