public class TwoSumStudent_26 {
    public static int[] solve(int[] data, int target) {
        
        for(int i=0; i<data.length; i++){
            for(int z=i+1; z<data.length; z++){
                if(data[i] + data[z] == target){
                    return new int[]{i, z};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}