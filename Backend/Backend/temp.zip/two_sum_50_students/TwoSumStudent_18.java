public class TwoSumStudent_18 {
    public static int[] solve(int[] data, int target) {
        
        int n = data.length;
        for(int index=0; index<n-1; index++){
            for(int pos=index+1; pos<n; pos++){
                int sum = data[index] + data[pos];
                if(sum == target){
                    return new int[]{index,pos};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}