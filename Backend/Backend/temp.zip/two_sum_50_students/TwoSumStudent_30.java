public class TwoSumStudent_30 {
    public static int[] solve(int[] numbers, int target) {
        
        for(int idx=0; idx<numbers.length; idx++){
            int need = target - numbers[idx];
            for(int z=0; z<numbers.length; z++){
                if(idx!=z && numbers[z] == need){
                    return new int[]{idx,z};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}