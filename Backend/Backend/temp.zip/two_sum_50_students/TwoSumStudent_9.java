public class TwoSumStudent_9 {
    public static int[] solve(int[] data, int target) {
        
        java.util.Map<Integer,Integer> hash = new java.util.HashMap<>();
        int i=0;
        while(i < data.length){
            int diff = target - data[i];
            if(hash.containsKey(diff)){
                return new int[]{hash.get(diff), i};
            }
            hash.put(data[i], i);
            i++;
        }
        return new int[]{-1,-1};
        
    }
}