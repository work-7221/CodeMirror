public class TwoSumStudent_10 {
    public static int[] solve(int[] arr, int target) {
        
        for(int x=0; x<arr.length; x++){
            int need = target - arr[x];
            for(int y=0; y<arr.length; y++){
                if(x!=y && arr[y] == need){
                    return new int[]{x,y};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}