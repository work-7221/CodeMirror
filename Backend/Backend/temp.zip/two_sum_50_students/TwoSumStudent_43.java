public class TwoSumStudent_43 {
    public static int[] solve(int[] arr, int target) {
        
        int n = arr.length;
        for(int idx=0; idx<n-1; idx++){
            for(int pos=idx+1; pos<n; pos++){
                int sum = arr[idx] + arr[pos];
                if(sum == target){
                    return new int[]{idx,pos};
                }
            }
        }
        return new int[]{-1,-1};
        
    }
}